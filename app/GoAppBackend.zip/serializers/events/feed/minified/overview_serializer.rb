module Events
  module Feed
    module Minified
      class OverviewSerializer < ApiSerializer
        attributes :id, :title
      end
    end
  end
end
