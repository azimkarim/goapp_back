module Identifications
  module Types
    class OverviewSerializer < ApiSerializer
      attributes :id, :name
    end
  end
end
