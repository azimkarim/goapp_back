module Platforms
  class PublicSerializer < ApiSerializer
    attributes :id, :name, :images
  end
end
