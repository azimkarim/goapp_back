module Groups
  class InvitationSerializer < ApiSerializer
    attributes :id, :status, :updated_at
  end
end
