class GalleryImageSerializer < ApiSerializer
  attributes :id, :images
end
