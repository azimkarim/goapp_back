module Application
  module UserHelper
    #NOTE: Intentionally Left Blank
  end
end
