module Application
  module Terms
    class TermsController < ApplicationController
      layout 'terms'

      def index; end

      def privacy_policy; end
    end
  end
end
