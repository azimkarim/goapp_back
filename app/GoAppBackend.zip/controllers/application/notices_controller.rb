module Application
  class NoticesController < WebController
    layout 'notice'

    def index
    end
  end
end
